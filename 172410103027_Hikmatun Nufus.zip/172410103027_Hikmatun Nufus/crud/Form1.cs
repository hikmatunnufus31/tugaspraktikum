using Npgsql;
using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace tugaspbo1
{
    public partial class Form1 : Form
    {
        private string connString = "Server=localhost; Port=5432; User Id=postgres; Password=12345678; Database=postgres";
        private NpgsqlConnection conn;
        private string sql;
        private NpgsqlCommand cmd;
        private DataTable dt;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new NpgsqlConnection(connString);
            cari();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
        }



        private void cari()
        {
            try
            {
                conn.Open();
                sql = @"select * from tokopedia";
                cmd = new NpgsqlCommand(sql, conn);
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error guys: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            cari();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            string create = @"insert into tokopedia (id_transaksi, nama_laptop, harga_laptop, stok_laptop, nama_pembeli, transaksi_pembeli, laptop_pembeli, qty_pembeli) values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "')";
            cmd = new NpgsqlCommand(create, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data berhasil diinput");
            conn.Close();
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.Open();
            string delete = @"delete from tokopedia where nama_laptop = '" + textBox10 + "'";
            cmd = new NpgsqlCommand(delete, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Data dihapus");
        }
    }
}